from streams.generators.sine1_stream import SINE1
from streams.generators.sine2_stream import SINE2
from streams.generators.mixed_stream import MIXED
from streams.generators.stagger_stream import STAGGER
from streams.generators.sea_stream import SEA
from streams.generators.circles_stream import CIRCLES
from streams.generators.led_stream import LEDConceptDrift

